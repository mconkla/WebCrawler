class CrawledArticles():
    def __init__(self, image, content, emoji, title):
        self.image = image
        self.content = content
        self.emoji = emoji
        self.title = title