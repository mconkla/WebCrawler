import crawler
import csv
#from crawler import *







fetcher = crawler.ArticleFetcher()

counter = 0

with open('crawldata.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for lala in fetcher.fetch():
        if counter == 16:
            break
        counter += 1
        writer.writerow([lala.emoji, lala.title, lala.content, lala.image])
